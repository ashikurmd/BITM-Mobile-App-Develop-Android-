package com.example.nishad.tourmate.constant;

/**
 * Created by Nishad on 8/21/2016.
 */
public class Constants {

    public static final String LOGIN_SIGNUP_ADD_EVENT = "loginOrSignUp";
    public static final String USER_EMAIL = "userEmail";
    public static final String USER_ID = "userId";

}
